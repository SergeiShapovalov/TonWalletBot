create database TON_data;
use TON_data;
create table TON_data_test
(
    id      bigint PRIMARY KEY,
    seed    varchar(1000000),
    wallet  varchar(1000000),
    balance varchar(100000)
);

create table hot_wallet
(
    seed varchar(100000),
    wallet varchar(100000)
);

create table ton_withdraw
(
    id      bigint ,
    wallet varchar(1000000),
    amount varchar(10000)
);

create table ton_price
(
    token varchar(10000),
    price varchar(1000)
);

insert into ton_price(token, price) values ('TON', '0');

insert into hot_wallet(seed, wallet) values ('wealth wealth need theme wealth ill canvas code impose canvas predict keen define wealth canvas happy sword theme govern sword theme wealth void drink', 'EQA0r2MiXTyxgEe5gpr-IX23gAgSVGu2GqppJTv_QuYVmgNh');


//id, balance