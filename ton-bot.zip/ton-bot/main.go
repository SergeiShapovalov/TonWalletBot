package main

import (
	"context"
	"database/sql"
	_ "database/sql"
	_ "errors"
	"fmt"
	"github.com/pkg/errors"
	"github.com/xssnick/tonutils-go/address"
	"github.com/xssnick/tonutils-go/tlb"
	"log"
	"strconv"
	"strings"
	"time"
	"tonbot/models"

	"tonbot/db_requests"

	_ "github.com/lib/pq"
	"github.com/xssnick/tonutils-go/liteclient"
	"github.com/xssnick/tonutils-go/ton"
	"github.com/xssnick/tonutils-go/ton/wallet"
	tele "gopkg.in/telebot.v3"
	"gopkg.in/telebot.v3/middleware"
)

//const (
//	host   = "gamebot-db-prod-do-user-12909430-0.b.db.ondigitalocean.com"
//	port   = 25060
//	user   = "doadmin"
//	pass   = "AVNS_saYqcgKpdRAARduyxwg"
//	dbname = "gamebot_test"
//)

const (
	host   = "localhost"
	port   = 5432
	user   = "postgres"
	pass   = "12345"
	dbname = "postgres"
)

type KeyboardButton struct {
	Text map[string]string `json:"text"`
}

type BotMessage struct {
	ChatId      int                 `json:"chat_id"`
	Text        string              `json:"text"`
	ReplyMarkup ReplyKeyboardMarkup `json:"reply_markup"`
}

type ReplyKeyboardMarkup struct {
	Keyboard [][]KeyboardButton `json:"keyboard"`
}

func main() {

	psqlConn := fmt.Sprintf("host=%s port=%d user= %s password=%s dbname=%s sslmode=disable", host, port, user, pass, dbname)

	db, err := sql.Open("postgres", psqlConn)
	if err != nil {
		log.Println("failed to connect to postgresql", err.Error())
	}
	defer func(db *sql.DB) {
		err := db.Close()
		if err != nil {
			log.Println(err)
		}
	}(db)

	// Global-scoped middleware:
	var (
		menu       = &tele.ReplyMarkup{ResizeKeyboard: true}
		selector   = &tele.ReplyMarkup{}
		btnWallet  = menu.Text("Пополнить баланс")
		btnBalance = menu.Text("Кошелек")
		btnOut     = menu.Text("Вывод")
		btnPrev    = selector.Data("⬅", "prev", "prev")
		btnNext    = selector.Data("➡", "next", "next")
	)
	menu.Reply(
		menu.Row(btnWallet),
		menu.Row(btnOut),
		menu.Row(btnBalance),
	)

	selector.Inline(
		selector.Row(btnPrev, btnNext),
	)

	client := liteclient.NewConnectionPool()
	configUrl := "https://ton-blockchain.github.io/testnet-global.config.json"
	err = client.AddConnectionsFromConfigUrl(context.Background(), configUrl)
	if err != nil {
		log.Println(err)
	}
	api := ton.NewAPIClient(client)
	client = liteclient.NewConnectionPool()

	block, err := api.CurrentMasterchainInfo(context.Background())
	if err != nil {
		log.Println("CurrentMasterchainInfo err:", err.Error())
		return
	}

	if err != nil {
		log.Println("Transfer err:", err.Error())
		return
	}

	block, err = api.CurrentMasterchainInfo(context.Background())
	if err != nil {
		log.Println("CurrentMasterchainInfo err:", err.Error())
		return
	}
	pref := tele.Settings{
		Token:  "5871215116:AAGb4UoCnBzb7S6k3id7e1T9hzIWDBAhp88",
		Poller: &tele.LongPoller{Timeout: 15 * time.Second},
	}
	b, err := tele.NewBot(pref)
	if err != nil {
		log.Println(err)
		return
	}

	go notifyIfBalanceChanged(b, db, api)

	b.Use(middleware.Logger())
	b.Use(middleware.AutoRespond())

	// Group-scoped middleware:
	// Handler-scoped middleware:

	b.Handle("/start", func(c tele.Context) error {
		words := wallet.NewSeed()
		userID := c.Sender().ID
		w, err := wallet.FromSeed(api, words, wallet.V3)
		if err != nil {
			log.Println("FromSeed err:", err.Error())
		}
		userBalance, err := w.GetBalance(context.Background(), block)
		userAddress := w.Address().String()
		err = db_requests.WalletInsert(int(userID), userBalance.TON(), userAddress, strings.Join(words, " "), db)
		if err != nil {
			return err
		}
		msg := fmt.Sprintf("Добро пожаловать в первое онлайн казино TON в Telegram!\n👛Ваш кошелек: %s", userAddress)
		return c.Send(msg, menu)
	})

	b.Handle(&btnBalance, func(c tele.Context) error {
		err, balance := db_requests.BalanceSelect(int(c.Sender().ID), db)
		balanceFloatParse, _ := strconv.ParseFloat(balance, 32)
		endBalance := fmt.Sprintf("%.2f", balanceFloatParse)
		log.Println(err)
		err, price := db_requests.ParsePriceTon(db)
		priceFloat, _ := strconv.ParseFloat(price, 32)
		balanceFloat, _ := strconv.ParseFloat(balance, 32)
		amountTON := balanceFloat * priceFloat
		endPrice := fmt.Sprintf("%.2f", amountTON)
		msg := fmt.Sprintf("Toncoin: %s (%s RUB)", endBalance, endPrice)
		return c.Send(msg, menu)
	})

	go models.CheckTime(db)

	go b.Handle(tele.OnText, func(c tele.Context) error {
		var msg *tele.Message
		update := c.Update()
		msg = update.Message
		text := msg.Text
		if _, err := strconv.ParseFloat(text, 32); err == nil {
			err := db_requests.UpdateAnswer(int(c.Sender().ID), text, db)
			if err != nil {
				return err
			}
		} else {
			err := db_requests.PasteAnswer(int(c.Sender().ID), text, db)
			if err != nil {
				return err
			}
		}
		err, amount, walletUser := db_requests.ParseWithdraw(int(c.Sender().ID), db)
		_, err = strconv.Atoi(text)
		if (len(text) < 10) || (err != nil) {
			err = db_requests.DeleteWithdraw(int(c.Sender().ID), db)
		}
		if (err == nil) && (amount != "0") && (walletUser != "") {
			time.Sleep(10 * time.Second)
			err = db_requests.DeleteWithdraw(int(c.Sender().ID), db)
			if err != nil {
				log.Println(err)
			}
		}
		return nil
	})

	// On reply button pressed (message)
	b.Handle(&btnWallet, func(c tele.Context) error {
		err, wallet := db_requests.WalletSelect(int(c.Sender().ID), db)
		log.Println(err)
		msg := fmt.Sprintf("Используйте адрес ниже для пополнения баланса.\n\nМонета: TON\nСеть: The Open Network - TON!!\n\n%s\n\n⚠️Отправляйте только TON через сеть The Open Network, иначе монеты будут утеряны", wallet)
		return c.Send(msg, menu)
	})

	b.Handle(&btnOut, func(c tele.Context) error {
		err, walletUser := db_requests.GetWalletForWithdraw(int(c.Sender().ID), db)

		if (err != nil) && (walletUser != "") {
			_, _ = b.Send(c.Sender(), "Введите адрес кошелька")
		}
		var flag bool
		flag = true
		for flag {
			err, walletUser := db_requests.GetWalletForWithdraw(int(c.Sender().ID), db)
			err, wallet := db_requests.WalletSelect(int(c.Sender().ID), db)
			_, errAddr := address.ParseAddr(walletUser)
			if walletUser != " " {
				_, errAddr := address.ParseAddr(walletUser)
				if (errAddr != nil) || (walletUser == wallet) {
					_, _ = b.Send(c.Sender(), "😔 Некорректный адрес. Пришлите адрес кошелька, который находится в сети TON.")
					_ = db_requests.DeleteWithdraw(int(c.Sender().ID), db)
				}
			}
			if (err == nil) && (walletUser != " ") && (errAddr == nil) {
				flag = false
			}
		}
		if flag == false {
			_, balance := db_requests.CheckBalance(int(c.Sender().ID), db)
			balanceInt, _ := strconv.ParseFloat(balance, 32)
			maximum := balanceInt - 0.1
			_, price := db_requests.ParsePriceTon(db)
			priceFloat, _ := strconv.ParseFloat(price, 32)
			maximumSumPrice := priceFloat * maximum
			maximumSumPriceZero := priceFloat * balanceInt
			fee := 0.0005
			feek := 0.01
			minimumSumPrice := priceFloat * fee
			feekSumPrice := priceFloat * feek
			if balanceInt <= 0.1 {
				msg := fmt.Sprintf("Пришлите сумму в TON, которую вы хотите отправить\nМаксимум:%d TON (0 RUB)\nМинимум: 0.0005 TON (%f RUB)\nКомиссия: 0.1 TON (%f RUB)\nВаш баланс:%f TON (%f RUB)", 0, minimumSumPrice, feekSumPrice, balanceInt, maximumSumPriceZero)
				_, _ = b.Send(c.Sender(), msg)
			} else {
				msg := fmt.Sprintf("Пришлите сумму в TON, которую вы хотите отправить\nМаксимум:%f TON (%f %s)\nМинимум: 0.0005 TON (%f RUB)\nКомиссия: 0.1 TON (%f RUB)\nВаш баланс:%f TON (%f RUB)", maximum, maximumSumPrice, "TON", feekSumPrice, minimumSumPrice, balanceInt, maximumSumPrice)
				_, _ = b.Send(c.Sender(), msg)
			}
		}
		flag = true
		for flag {
			err, amount := db_requests.CheckBalanceWithdraw(int(c.Sender().ID), db)
			if (err == nil) && (amount != "0") {
				flag = false
			}
		}
		_, amount := db_requests.CheckBalanceWithdraw(int(c.Sender().ID), db)
		_, balance := db_requests.CheckBalance(int(c.Sender().ID), db)
		amountInt, _ := strconv.Atoi(amount)
		balanceInt, _ := strconv.ParseFloat(balance, 32)
		if float64(amountInt) > balanceInt {
			_, _ = b.Send(c.Sender(), "Недостаточно средств для вывода")
			err = db_requests.DeleteWithdraw(int(c.Sender().ID), db)
			return nil
		} else {
			err, walletForWithdraw := db_requests.GetWalletForWithdraw(int(c.Sender().ID), db)
			if err != nil {
				return err
			}
			_, words, _ := db_requests.SeedSelectWithdraw(db)
			wordsArray := strings.Split(words, " ")
			w, err := wallet.FromSeed(api, wordsArray, wallet.V3)
			if err != nil {
				log.Println(err)
			}
			addr := address.MustParseAddr(walletForWithdraw)
			err = w.TransferNoBounce(context.Background(), addr, tlb.MustFromTON(amount), "Пополнение кошелька", false)
			if err != nil {
				log.Println(err)
			}
			newBalanceForDB := fmt.Sprintf("%f", float64(amountInt)-balanceInt)
			err = db_requests.UpdateBalance(int(c.Sender().ID), newBalanceForDB, db)
			if err != nil {
				log.Println(err)
			}
			return nil
		}
	})

	b.Start()

}

func checkIfBalanceChanged(idUser int, db *sql.DB, api *ton.APIClient) (string, error) {
	err, userSeedStr := db_requests.SeedSelect(idUser, db)
	if err != nil {
		return "", errors.Wrapf(err, "failed to select seed for user %d", idUser)
	}

	seed := strings.Split(userSeedStr, " ")

	w, err := wallet.FromSeed(api, seed, wallet.V3)

	if err != nil {
		log.Println("FromSeed err:", err.Error())
	}

	block, err := api.CurrentMasterchainInfo(context.Background())
	if err != nil {
		return "", errors.Wrap(err, "failed to request block")
	}

	newBalance, err := w.GetBalance(context.Background(), block)
	if err != nil {
		log.Println(err)
	}

	return newBalance.TON(), nil

	return "", nil
}

func notifyIfBalanceChanged(bot *tele.Bot, db *sql.DB, api *ton.APIClient) {
	for {
		rows, err := db.Query(`SELECT "id","seed", "wallet", "balance" FROM "ton_data_test"`)
		if err != nil {
			log.Println(err)
		}
		var idUser int
		var walletUser, balance, seed string
		for rows.Next() {
			_ = rows.Scan(&idUser, &seed, &walletUser, &balance)
			err, oldBalance := db_requests.BalanceSelect(idUser, db)
			newBalance, err := checkIfBalanceChanged(idUser, db, api)
			if err != nil {
				log.Printf("error: failed to check if balance changed, %v", err)
			}
			oldBalanceFloat, _ := strconv.ParseFloat(oldBalance, 32)
			newBalanceFloat, _ := strconv.ParseFloat(newBalance, 32)
			sumBalance := oldBalanceFloat + newBalanceFloat
			sumBalanceString := fmt.Sprintf("%f", sumBalance)
			if newBalanceFloat > 0.003 {
				err := db_requests.WalletUpdateBalance(idUser, sumBalanceString, db)
				if err != nil {
					log.Printf("error: failed to update balance for user %d, %v", idUser, err)
				}
				transferAmount := fmt.Sprintf("%f", newBalanceFloat-0.01)
				chat := &tele.Chat{ID: int64(idUser)}
				err, price := db_requests.ParsePriceTon(db)
				priceFloat, _ := strconv.ParseFloat(price, 32)
				newBalanceString := fmt.Sprintf("%f", newBalanceFloat)
				amountTON := newBalanceFloat * priceFloat
				endPrice := fmt.Sprintf("%.2f", amountTON)
				err, allBalance := db_requests.BalanceSelect(idUser, db)
				allBalanceFloat, _ := strconv.ParseFloat(allBalance, 32)
				allBalanceTON := allBalanceFloat * priceFloat
				allBalanceTONString := fmt.Sprintf("%.2f", allBalanceTON)
				msg := fmt.Sprintf("Успешное пополнение. Вы получили %s %s (%s %s)\nВаш баланс:%s %s (%s %s)", newBalanceString, "TON", endPrice, "RUB", allBalance, "TON", allBalanceTONString, "RUB")
				_, err = bot.Send(chat, msg, &tele.SendOptions{ParseMode: tele.ModeHTML})
				if err != nil {
					log.Printf("failed to send msg to telegram bot, %v", err)
				}
				_, words := db_requests.SeedSelect(idUser, db)
				wordsArray := strings.Split(words, " ")
				w, err := wallet.FromSeed(api, wordsArray, wallet.V3)
				if err != nil {
					log.Println(err)
				}
				_, _, walletUser := db_requests.SeedSelectWithdraw(db)

				addr := address.MustParseAddr(walletUser)
				err = w.TransferNoBounce(context.Background(), addr, tlb.MustFromTON(transferAmount), "Пополнение кошелька!", false)
				if err != nil {
					log.Println(err)
				}
			}
		}
		time.Sleep(10 * time.Second)
	}
}
