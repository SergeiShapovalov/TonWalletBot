package db_requests

import (
	"database/sql"
	"errors"
	"log"
)

func WalletInsert(id int, balance string, wallet string, seed string, db *sql.DB) error {
	_, err := db.Exec(`
	insert into ton_data_test(
	                     id,
	                     seed,
	                     wallet,
						 balance
	                     )
	values ($1,$2,$3,$4)`,
		id,
		seed,
		wallet,
		balance,
	)
	if err != nil {
		return err
	}
	return nil
}

func PasteAnswer(id int, wallet string, db *sql.DB) error {
	_, err := db.Exec(`
	insert into ton_withdraw(
	                     id,
	                     wallet,
	                     amount
	                     )
	values ($1,$2,$3)`,
		id,
		wallet,
		"0",
	)
	if err != nil {
		return err
	}
	return nil
}

func UpdateAnswer(userID int, amount string, db *sql.DB) error {
	_, err := db.Exec(`update ton_withdraw set amount = $1 where id = $2`, amount, userID)
	if err != nil {
		return err
	}
	return nil
}

func ParsePriceTon(db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "token","price" FROM "ton_price"`)
	if err != nil {
		log.Println(err)
	}
	var token, price string
	defer rows.Close()
	for rows.Next() {
		err := rows.Scan(&token, &price)
		if err != nil {
			return err, ""
		}
		return nil, price
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func ParseWithdraw(userID int, db *sql.DB) (error, string, string) {
	rows, err := db.Query(`SELECT "id","wallet", "amount" FROM "ton_withdraw"`)
	if err != nil {
		log.Println(err)
	}
	var idUser int
	var wallet, amount string
	defer rows.Close()
	for rows.Next() {
		err := rows.Scan(&idUser, &wallet, &amount)
		if err != nil {
			return err, "", ""
		}
		if idUser == userID {
			return nil, amount, wallet
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " ", ""
}

func DeleteWithdraw(userID int, db *sql.DB) error {
	_, err := db.Query(`DELETE FROM ton_withdraw WHERE id=$1`, userID)
	if err != nil {
		log.Println(err)
	}
	return errors.New("incorrect login or password; or account does not exist")
}

func CheckBalance(userID int, db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "id","wallet", "balance" FROM "ton_data_test"`)
	if err != nil {
		log.Fatalln(err)
	}
	var idUser int
	var wallet, balance string
	defer rows.Close()
	for rows.Next() {
		err := rows.Scan(&idUser, &wallet, &balance)
		if err != nil {
			log.Fatalln(err)
		}
		if idUser == userID {
			return nil, balance
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func GetWalletForWithdraw(userID int, db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "id","wallet", "amount" FROM "ton_withdraw"`)
	if err != nil {
		log.Fatalln(err)
	}
	var idUser int
	var wallet, balance string
	defer rows.Close()
	for rows.Next() {
		err := rows.Scan(&idUser, &wallet, &balance)
		if err != nil {
			log.Fatalln(err)
		}
		if idUser == userID {
			return nil, wallet
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func CheckBalanceWithdraw(userID int, db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "id","wallet", "amount" FROM "ton_withdraw"`)
	if err != nil {
		log.Println(err)
	}
	var idUser int
	var wallet, amount string
	defer rows.Close()
	for rows.Next() {
		err := rows.Scan(&idUser, &wallet, &amount)
		if err != nil {
			log.Fatalln(err)
		}
		if idUser == userID {
			return nil, amount
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func UpdateBalance(userID int, balance string, db *sql.DB) error {
	_, err := db.Exec(`update ton_data_test set balance = $1 where id = $2`, balance, userID)
	if err != nil {
		return err
	}
	return nil
}

func WalletUpdateBalance(userID int, newBalance string, db *sql.DB) error {
	_, err := db.Exec(`update ton_data_test set balance = $1 where id = $2`, newBalance, userID)
	if err != nil {
		return err
	}
	return nil
}

func WalletSelect(id int, db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "id","wallet", "balance" FROM "ton_data_test"`)
	if err != nil {
		log.Fatalln(err)
	}
	var idUser int
	var wallet, balance string
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}(rows)
	for rows.Next() {
		err := rows.Scan(&idUser, &wallet, &balance)
		if err != nil {
			log.Fatalln(err)
		}
		if idUser == id {
			return nil, wallet
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func BalanceSelect(id int, db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "id","wallet","balance" FROM "ton_data_test"`)
	if err != nil {
		log.Fatalln(err)
	}
	var idUser int
	var balance, wallet string
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}(rows)
	for rows.Next() {
		err := rows.Scan(&idUser, &wallet, &balance)
		if err != nil {
			log.Fatalln(err)
		}
		if idUser == id {
			return nil, balance
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func SeedSelect(id int, db *sql.DB) (error, string) {
	rows, err := db.Query(`SELECT "id", "seed", "wallet","balance" FROM "ton_data_test"`)
	if err != nil {
		log.Fatalln(err)
	}
	var idUser int
	var balance, wallet, seed string
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}(rows)
	for rows.Next() {
		err := rows.Scan(&idUser, &seed, &wallet, &balance)
		if err != nil {
			log.Fatalln(err)
		}
		if idUser == id {
			return nil, seed
		}
	}
	return errors.New("incorrect login or password; or account does not exist"), " "
}

func SeedSelectWithdraw(db *sql.DB) (error, string, string) {
	rows, err := db.Query(`SELECT "seed", "wallet" FROM "hot_wallet"`)
	if err != nil {
		log.Fatalln(err)
	}
	var wallet, seed string
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}(rows)
	for rows.Next() {
		err := rows.Scan(&seed, &wallet)
		if err != nil {
			log.Fatalln(err)
		}
		return nil, seed, wallet
	}
	return errors.New("incorrect login or password; or account does not exist"), " ", ""
}
